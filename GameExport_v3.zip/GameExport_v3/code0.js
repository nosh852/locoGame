gdjs.GameScene1Code = {};
gdjs.GameScene1Code.localVariables = [];
gdjs.GameScene1Code.forEachCount0_3 = 0;

gdjs.GameScene1Code.forEachCount1_3 = 0;

gdjs.GameScene1Code.forEachIndex3 = 0;

gdjs.GameScene1Code.forEachObjects3 = [];

gdjs.GameScene1Code.forEachTotalCount3 = 0;

gdjs.GameScene1Code.GDPlayerObjects1= [];
gdjs.GameScene1Code.GDPlayerObjects2= [];
gdjs.GameScene1Code.GDPlayerObjects3= [];
gdjs.GameScene1Code.GDPlayerObjects4= [];
gdjs.GameScene1Code.GDNewTiledSpriteObjects1= [];
gdjs.GameScene1Code.GDNewTiledSpriteObjects2= [];
gdjs.GameScene1Code.GDNewTiledSpriteObjects3= [];
gdjs.GameScene1Code.GDNewTiledSpriteObjects4= [];
gdjs.GameScene1Code.GDPeachObjects1= [];
gdjs.GameScene1Code.GDPeachObjects2= [];
gdjs.GameScene1Code.GDPeachObjects3= [];
gdjs.GameScene1Code.GDPeachObjects4= [];
gdjs.GameScene1Code.GDBurgerObjects1= [];
gdjs.GameScene1Code.GDBurgerObjects2= [];
gdjs.GameScene1Code.GDBurgerObjects3= [];
gdjs.GameScene1Code.GDBurgerObjects4= [];
gdjs.GameScene1Code.GDpizzaObjects1= [];
gdjs.GameScene1Code.GDpizzaObjects2= [];
gdjs.GameScene1Code.GDpizzaObjects3= [];
gdjs.GameScene1Code.GDpizzaObjects4= [];
gdjs.GameScene1Code.GDtableObjects1= [];
gdjs.GameScene1Code.GDtableObjects2= [];
gdjs.GameScene1Code.GDtableObjects3= [];
gdjs.GameScene1Code.GDtableObjects4= [];
gdjs.GameScene1Code.GDwingObjects1= [];
gdjs.GameScene1Code.GDwingObjects2= [];
gdjs.GameScene1Code.GDwingObjects3= [];
gdjs.GameScene1Code.GDwingObjects4= [];
gdjs.GameScene1Code.GDcookieObjects1= [];
gdjs.GameScene1Code.GDcookieObjects2= [];
gdjs.GameScene1Code.GDcookieObjects3= [];
gdjs.GameScene1Code.GDcookieObjects4= [];
gdjs.GameScene1Code.GDKetchupObjects1= [];
gdjs.GameScene1Code.GDKetchupObjects2= [];
gdjs.GameScene1Code.GDKetchupObjects3= [];
gdjs.GameScene1Code.GDKetchupObjects4= [];
gdjs.GameScene1Code.GDSpawnPointObjects1= [];
gdjs.GameScene1Code.GDSpawnPointObjects2= [];
gdjs.GameScene1Code.GDSpawnPointObjects3= [];
gdjs.GameScene1Code.GDSpawnPointObjects4= [];
gdjs.GameScene1Code.GDpeach_95952Objects1= [];
gdjs.GameScene1Code.GDpeach_95952Objects2= [];
gdjs.GameScene1Code.GDpeach_95952Objects3= [];
gdjs.GameScene1Code.GDpeach_95952Objects4= [];
gdjs.GameScene1Code.GDScrollGroundObjects1= [];
gdjs.GameScene1Code.GDScrollGroundObjects2= [];
gdjs.GameScene1Code.GDScrollGroundObjects3= [];
gdjs.GameScene1Code.GDScrollGroundObjects4= [];
gdjs.GameScene1Code.GDScrollGround2Objects1= [];
gdjs.GameScene1Code.GDScrollGround2Objects2= [];
gdjs.GameScene1Code.GDScrollGround2Objects3= [];
gdjs.GameScene1Code.GDScrollGround2Objects4= [];
gdjs.GameScene1Code.GDCoinObjects1= [];
gdjs.GameScene1Code.GDCoinObjects2= [];
gdjs.GameScene1Code.GDCoinObjects3= [];
gdjs.GameScene1Code.GDCoinObjects4= [];
gdjs.GameScene1Code.GDlogoObjects1= [];
gdjs.GameScene1Code.GDlogoObjects2= [];
gdjs.GameScene1Code.GDlogoObjects3= [];
gdjs.GameScene1Code.GDlogoObjects4= [];
gdjs.GameScene1Code.GDScoreTitleObjects1= [];
gdjs.GameScene1Code.GDScoreTitleObjects2= [];
gdjs.GameScene1Code.GDScoreTitleObjects3= [];
gdjs.GameScene1Code.GDScoreTitleObjects4= [];
gdjs.GameScene1Code.GDLivesLeftObjects1= [];
gdjs.GameScene1Code.GDLivesLeftObjects2= [];
gdjs.GameScene1Code.GDLivesLeftObjects3= [];
gdjs.GameScene1Code.GDLivesLeftObjects4= [];
gdjs.GameScene1Code.GDButton_9595AObjects1= [];
gdjs.GameScene1Code.GDButton_9595AObjects2= [];
gdjs.GameScene1Code.GDButton_9595AObjects3= [];
gdjs.GameScene1Code.GDButton_9595AObjects4= [];
gdjs.GameScene1Code.GDB_9595buttonObjects1= [];
gdjs.GameScene1Code.GDB_9595buttonObjects2= [];
gdjs.GameScene1Code.GDB_9595buttonObjects3= [];
gdjs.GameScene1Code.GDB_9595buttonObjects4= [];
gdjs.GameScene1Code.GDCoinScoreObjects1= [];
gdjs.GameScene1Code.GDCoinScoreObjects2= [];
gdjs.GameScene1Code.GDCoinScoreObjects3= [];
gdjs.GameScene1Code.GDCoinScoreObjects4= [];
gdjs.GameScene1Code.GDScoreRunObjects1= [];
gdjs.GameScene1Code.GDScoreRunObjects2= [];
gdjs.GameScene1Code.GDScoreRunObjects3= [];
gdjs.GameScene1Code.GDScoreRunObjects4= [];
gdjs.GameScene1Code.GDgameboy_9595joystickObjects1= [];
gdjs.GameScene1Code.GDgameboy_9595joystickObjects2= [];
gdjs.GameScene1Code.GDgameboy_9595joystickObjects3= [];
gdjs.GameScene1Code.GDgameboy_9595joystickObjects4= [];
gdjs.GameScene1Code.GDSave_9595ButtonObjects1= [];
gdjs.GameScene1Code.GDSave_9595ButtonObjects2= [];
gdjs.GameScene1Code.GDSave_9595ButtonObjects3= [];
gdjs.GameScene1Code.GDSave_9595ButtonObjects4= [];
gdjs.GameScene1Code.GDRestart_9595ButtonObjects1= [];
gdjs.GameScene1Code.GDRestart_9595ButtonObjects2= [];
gdjs.GameScene1Code.GDRestart_9595ButtonObjects3= [];
gdjs.GameScene1Code.GDRestart_9595ButtonObjects4= [];
gdjs.GameScene1Code.GDGameOverObjects1= [];
gdjs.GameScene1Code.GDGameOverObjects2= [];
gdjs.GameScene1Code.GDGameOverObjects3= [];
gdjs.GameScene1Code.GDGameOverObjects4= [];
gdjs.GameScene1Code.GDScrollGroundStillObjects1= [];
gdjs.GameScene1Code.GDScrollGroundStillObjects2= [];
gdjs.GameScene1Code.GDScrollGroundStillObjects3= [];
gdjs.GameScene1Code.GDScrollGroundStillObjects4= [];
gdjs.GameScene1Code.GDFinalCoinScoreObjects1= [];
gdjs.GameScene1Code.GDFinalCoinScoreObjects2= [];
gdjs.GameScene1Code.GDFinalCoinScoreObjects3= [];
gdjs.GameScene1Code.GDFinalCoinScoreObjects4= [];
gdjs.GameScene1Code.GDRegister_9595ButtonObjects1= [];
gdjs.GameScene1Code.GDRegister_9595ButtonObjects2= [];
gdjs.GameScene1Code.GDRegister_9595ButtonObjects3= [];
gdjs.GameScene1Code.GDRegister_9595ButtonObjects4= [];


gdjs.GameScene1Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Button_A"), gdjs.GameScene1Code.GDButton_9595AObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameScene1Code.GDButton_9595AObjects1.length;i<l;++i) {
    if ( gdjs.GameScene1Code.GDButton_9595AObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameScene1Code.GDButton_9595AObjects1[k] = gdjs.GameScene1Code.GDButton_9595AObjects1[i];
        ++k;
    }
}
gdjs.GameScene1Code.GDButton_9595AObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameScene1Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.GameScene1Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{for(var i = 0, len = gdjs.GameScene1Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("jump");
}
}}

}


};gdjs.GameScene1Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameScene1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.GameScene1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameScene1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_1 = true;
        gdjs.GameScene1Code.GDPlayerObjects2[k] = gdjs.GameScene1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameScene1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.GameScene1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.GameScene1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_1 = true;
        gdjs.GameScene1Code.GDPlayerObjects2[k] = gdjs.GameScene1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameScene1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false, false);
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameScene1Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameScene1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Run");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameScene1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameScene1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameScene1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.GameScene1Code.GDPlayerObjects2[k] = gdjs.GameScene1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameScene1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameScene1Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameScene1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("jump");
}
}{for(var i = 0, len = gdjs.GameScene1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setGravity(800);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("B_button"), gdjs.GameScene1Code.GDB_9595buttonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameScene1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameScene1Code.GDB_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.GameScene1Code.GDB_9595buttonObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameScene1Code.GDB_9595buttonObjects2[k] = gdjs.GameScene1Code.GDB_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.GameScene1Code.GDB_9595buttonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.GameScene1Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameScene1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_1 = true;
        gdjs.GameScene1Code.GDPlayerObjects2[k] = gdjs.GameScene1Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameScene1Code.GDPlayerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false, false);
}
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameScene1Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameScene1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("down");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false, false);
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameScene1Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.GameScene1Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("down");
}
}}

}


};gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDtableObjects3Objects = Hashtable.newFrom({"table": gdjs.GameScene1Code.GDtableObjects3});
gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDpeach_959595952Objects3Objects = Hashtable.newFrom({"peach_2": gdjs.GameScene1Code.GDpeach_95952Objects3});
gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDBurgerObjects3Objects = Hashtable.newFrom({"Burger": gdjs.GameScene1Code.GDBurgerObjects3});
gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDpizzaObjects3Objects = Hashtable.newFrom({"pizza": gdjs.GameScene1Code.GDpizzaObjects3});
gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDwingObjects3Objects = Hashtable.newFrom({"wing": gdjs.GameScene1Code.GDwingObjects3});
gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDcookieObjects3Objects = Hashtable.newFrom({"cookie": gdjs.GameScene1Code.GDcookieObjects3});
gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDKetchupObjects2Objects = Hashtable.newFrom({"Ketchup": gdjs.GameScene1Code.GDKetchupObjects2});
gdjs.GameScene1Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10066300);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.GameScene1Code.GDSpawnPointObjects3);
gdjs.GameScene1Code.GDtableObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDtableObjects3Objects, (( gdjs.GameScene1Code.GDSpawnPointObjects3.length === 0 ) ? 0 :gdjs.GameScene1Code.GDSpawnPointObjects3[0].getPointX("")), 550, "");
}{for(var i = 0, len = gdjs.GameScene1Code.GDtableObjects3.length ;i < len;++i) {
    gdjs.GameScene1Code.GDtableObjects3[i].getBehavior("Resizable").setSize(132, 126);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10067548);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.GameScene1Code.GDSpawnPointObjects3);
gdjs.GameScene1Code.GDpeach_95952Objects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDpeach_959595952Objects3Objects, (( gdjs.GameScene1Code.GDSpawnPointObjects3.length === 0 ) ? 0 :gdjs.GameScene1Code.GDSpawnPointObjects3[0].getPointX("")), gdjs.randomInRange(445, 608), "");
}{for(var i = 0, len = gdjs.GameScene1Code.GDpeach_95952Objects3.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpeach_95952Objects3[i].getBehavior("Resizable").setSize(61, 31);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10069132);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.GameScene1Code.GDSpawnPointObjects3);
gdjs.GameScene1Code.GDBurgerObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDBurgerObjects3Objects, (( gdjs.GameScene1Code.GDSpawnPointObjects3.length === 0 ) ? 0 :gdjs.GameScene1Code.GDSpawnPointObjects3[0].getPointX("")), gdjs.randomInRange(390, 608), "");
}{for(var i = 0, len = gdjs.GameScene1Code.GDBurgerObjects3.length ;i < len;++i) {
    gdjs.GameScene1Code.GDBurgerObjects3[i].getBehavior("Resizable").setSize(73, 49);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10070732);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.GameScene1Code.GDSpawnPointObjects3);
gdjs.GameScene1Code.GDpizzaObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDpizzaObjects3Objects, (( gdjs.GameScene1Code.GDSpawnPointObjects3.length === 0 ) ? 0 :gdjs.GameScene1Code.GDSpawnPointObjects3[0].getPointX("")), gdjs.randomInRange(390, 608), "");
}{for(var i = 0, len = gdjs.GameScene1Code.GDpizzaObjects3.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpizzaObjects3[i].getBehavior("Resizable").setSize(66, 51);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 4;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10072316);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.GameScene1Code.GDSpawnPointObjects3);
gdjs.GameScene1Code.GDwingObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDwingObjects3Objects, (( gdjs.GameScene1Code.GDSpawnPointObjects3.length === 0 ) ? 0 :gdjs.GameScene1Code.GDSpawnPointObjects3[0].getPointX("")), gdjs.randomInRange(445, 608), "");
}{for(var i = 0, len = gdjs.GameScene1Code.GDwingObjects3.length ;i < len;++i) {
    gdjs.GameScene1Code.GDwingObjects3[i].getBehavior("Resizable").setSize(42, 24);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10073892);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.GameScene1Code.GDSpawnPointObjects3);
gdjs.GameScene1Code.GDcookieObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDcookieObjects3Objects, (( gdjs.GameScene1Code.GDSpawnPointObjects3.length === 0 ) ? 0 :gdjs.GameScene1Code.GDSpawnPointObjects3[0].getPointX("")), gdjs.randomInRange(390, 608), "");
}{for(var i = 0, len = gdjs.GameScene1Code.GDcookieObjects3.length ;i < len;++i) {
    gdjs.GameScene1Code.GDcookieObjects3[i].getBehavior("Resizable").setSize(38, 42);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 6;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10075484);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.GameScene1Code.GDSpawnPointObjects2);
gdjs.GameScene1Code.GDKetchupObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDKetchupObjects2Objects, (( gdjs.GameScene1Code.GDSpawnPointObjects2.length === 0 ) ? 0 :gdjs.GameScene1Code.GDSpawnPointObjects2[0].getPointX("")), gdjs.randomInRange(390, 608), "");
}{for(var i = 0, len = gdjs.GameScene1Code.GDKetchupObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDKetchupObjects2[i].getBehavior("Resizable").setSize(32, 32);
}
}}

}


};gdjs.GameScene1Code.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "objectsTimer", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(0, 6));
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(gdjs.randomInRange(1.2, 3));
}
{ //Subevents
gdjs.GameScene1Code.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burger"), gdjs.GameScene1Code.GDBurgerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ketchup"), gdjs.GameScene1Code.GDKetchupObjects2);
gdjs.copyArray(runtimeScene.getObjects("Restart_Button"), gdjs.GameScene1Code.GDRestart_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("cookie"), gdjs.GameScene1Code.GDcookieObjects2);
gdjs.copyArray(runtimeScene.getObjects("peach_2"), gdjs.GameScene1Code.GDpeach_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("pizza"), gdjs.GameScene1Code.GDpizzaObjects2);
gdjs.copyArray(runtimeScene.getObjects("table"), gdjs.GameScene1Code.GDtableObjects2);
gdjs.copyArray(runtimeScene.getObjects("wing"), gdjs.GameScene1Code.GDwingObjects2);
{for(var i = 0, len = gdjs.GameScene1Code.GDBurgerObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDBurgerObjects2[i].hide();
}
for(var i = 0, len = gdjs.GameScene1Code.GDpizzaObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpizzaObjects2[i].hide();
}
for(var i = 0, len = gdjs.GameScene1Code.GDwingObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDwingObjects2[i].hide();
}
for(var i = 0, len = gdjs.GameScene1Code.GDcookieObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDcookieObjects2[i].hide();
}
for(var i = 0, len = gdjs.GameScene1Code.GDtableObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDtableObjects2[i].hide();
}
for(var i = 0, len = gdjs.GameScene1Code.GDKetchupObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDKetchupObjects2[i].hide();
}
for(var i = 0, len = gdjs.GameScene1Code.GDpeach_95952Objects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpeach_95952Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameScene1Code.GDRestart_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDRestart_9595ButtonObjects2[i].hide(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Restart_Button"), gdjs.GameScene1Code.GDRestart_9595ButtonObjects1);
{for(var i = 0, len = gdjs.GameScene1Code.GDRestart_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDRestart_9595ButtonObjects1[i].hide();
}
}}

}


};gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDCoinObjects3Objects = Hashtable.newFrom({"Coin": gdjs.GameScene1Code.GDCoinObjects3});
gdjs.GameScene1Code.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10079372);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.GameScene1Code.GDSpawnPointObjects3);
gdjs.GameScene1Code.GDCoinObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDCoinObjects3Objects, (( gdjs.GameScene1Code.GDSpawnPointObjects3.length === 0 ) ? 0 :gdjs.GameScene1Code.GDSpawnPointObjects3[0].getPointX("")), gdjs.randomInRange(379, 600), "");
}{for(var i = 0, len = gdjs.GameScene1Code.GDCoinObjects3.length ;i < len;++i) {
    gdjs.GameScene1Code.GDCoinObjects3[i].getBehavior("Resizable").setSize(50, 50);
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.GameScene1Code.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "coinTimer", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameScene1Code.eventsList4(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) < 5);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(2);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.GameScene1Code.GDCoinObjects1);
{for(var i = 0, len = gdjs.GameScene1Code.GDCoinObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDCoinObjects1[i].hide();
}
}}

}


};gdjs.GameScene1Code.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Burger"), gdjs.GameScene1Code.GDBurgerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ketchup"), gdjs.GameScene1Code.GDKetchupObjects2);
gdjs.copyArray(runtimeScene.getObjects("cookie"), gdjs.GameScene1Code.GDcookieObjects2);
gdjs.copyArray(runtimeScene.getObjects("peach_2"), gdjs.GameScene1Code.GDpeach_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("pizza"), gdjs.GameScene1Code.GDpizzaObjects2);
gdjs.copyArray(runtimeScene.getObjects("table"), gdjs.GameScene1Code.GDtableObjects2);
gdjs.copyArray(runtimeScene.getObjects("wing"), gdjs.GameScene1Code.GDwingObjects2);
{for(var i = 0, len = gdjs.GameScene1Code.GDBurgerObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDBurgerObjects2[i].setX(gdjs.GameScene1Code.GDBurgerObjects2[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))));
}
for(var i = 0, len = gdjs.GameScene1Code.GDpizzaObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpizzaObjects2[i].setX(gdjs.GameScene1Code.GDpizzaObjects2[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))));
}
for(var i = 0, len = gdjs.GameScene1Code.GDwingObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDwingObjects2[i].setX(gdjs.GameScene1Code.GDwingObjects2[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))));
}
for(var i = 0, len = gdjs.GameScene1Code.GDcookieObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDcookieObjects2[i].setX(gdjs.GameScene1Code.GDcookieObjects2[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))));
}
for(var i = 0, len = gdjs.GameScene1Code.GDtableObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDtableObjects2[i].setX(gdjs.GameScene1Code.GDtableObjects2[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))));
}
for(var i = 0, len = gdjs.GameScene1Code.GDKetchupObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDKetchupObjects2[i].setX(gdjs.GameScene1Code.GDKetchupObjects2[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))));
}
for(var i = 0, len = gdjs.GameScene1Code.GDpeach_95952Objects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpeach_95952Objects2[i].setX(gdjs.GameScene1Code.GDpeach_95952Objects2[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.GameScene1Code.GDCoinObjects1);
{for(var i = 0, len = gdjs.GameScene1Code.GDCoinObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDCoinObjects1[i].setX(gdjs.GameScene1Code.GDCoinObjects1[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))));
}
}}

}


};gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.GameScene1Code.GDPlayerObjects1});
gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDBurgerObjects1ObjectsGDgdjs_9546GameScene1Code_9546GDpizzaObjects1ObjectsGDgdjs_9546GameScene1Code_9546GDwingObjects1ObjectsGDgdjs_9546GameScene1Code_9546GDcookieObjects1ObjectsGDgdjs_9546GameScene1Code_9546GDtableObjects1ObjectsGDgdjs_9546GameScene1Code_9546GDKetchupObjects1ObjectsGDgdjs_9546GameScene1Code_9546GDpeach_959595952Objects1Objects = Hashtable.newFrom({"Burger": gdjs.GameScene1Code.GDBurgerObjects1, "pizza": gdjs.GameScene1Code.GDpizzaObjects1, "wing": gdjs.GameScene1Code.GDwingObjects1, "cookie": gdjs.GameScene1Code.GDcookieObjects1, "table": gdjs.GameScene1Code.GDtableObjects1, "Ketchup": gdjs.GameScene1Code.GDKetchupObjects1, "peach_2": gdjs.GameScene1Code.GDpeach_95952Objects1});
gdjs.GameScene1Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Burger"), gdjs.GameScene1Code.GDBurgerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Ketchup"), gdjs.GameScene1Code.GDKetchupObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameScene1Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("cookie"), gdjs.GameScene1Code.GDcookieObjects1);
gdjs.copyArray(runtimeScene.getObjects("peach_2"), gdjs.GameScene1Code.GDpeach_95952Objects1);
gdjs.copyArray(runtimeScene.getObjects("pizza"), gdjs.GameScene1Code.GDpizzaObjects1);
gdjs.copyArray(runtimeScene.getObjects("table"), gdjs.GameScene1Code.GDtableObjects1);
gdjs.copyArray(runtimeScene.getObjects("wing"), gdjs.GameScene1Code.GDwingObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDPlayerObjects1Objects, gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDBurgerObjects1ObjectsGDgdjs_9546GameScene1Code_9546GDpizzaObjects1ObjectsGDgdjs_9546GameScene1Code_9546GDwingObjects1ObjectsGDgdjs_9546GameScene1Code_9546GDcookieObjects1ObjectsGDgdjs_9546GameScene1Code_9546GDtableObjects1ObjectsGDgdjs_9546GameScene1Code_9546GDKetchupObjects1ObjectsGDgdjs_9546GameScene1Code_9546GDpeach_959595952Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(true);
}}

}


};gdjs.GameScene1Code.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burger"), gdjs.GameScene1Code.GDBurgerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ketchup"), gdjs.GameScene1Code.GDKetchupObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameScene1Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("cookie"), gdjs.GameScene1Code.GDcookieObjects2);
gdjs.copyArray(runtimeScene.getObjects("peach_2"), gdjs.GameScene1Code.GDpeach_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("pizza"), gdjs.GameScene1Code.GDpizzaObjects2);
gdjs.copyArray(runtimeScene.getObjects("table"), gdjs.GameScene1Code.GDtableObjects2);
gdjs.copyArray(runtimeScene.getObjects("wing"), gdjs.GameScene1Code.GDwingObjects2);
{for(var i = 0, len = gdjs.GameScene1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("dead");
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(0);
}{for(var i = 0, len = gdjs.GameScene1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setMaxFallingSpeed(0, false);
}
}{for(var i = 0, len = gdjs.GameScene1Code.GDBurgerObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDBurgerObjects2[i].getBehavior("Animation").pauseAnimation();
}
for(var i = 0, len = gdjs.GameScene1Code.GDpizzaObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpizzaObjects2[i].getBehavior("Animation").pauseAnimation();
}
for(var i = 0, len = gdjs.GameScene1Code.GDwingObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDwingObjects2[i].getBehavior("Animation").pauseAnimation();
}
for(var i = 0, len = gdjs.GameScene1Code.GDcookieObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDcookieObjects2[i].getBehavior("Animation").pauseAnimation();
}
for(var i = 0, len = gdjs.GameScene1Code.GDtableObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDtableObjects2[i].getBehavior("Animation").pauseAnimation();
}
for(var i = 0, len = gdjs.GameScene1Code.GDKetchupObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDKetchupObjects2[i].getBehavior("Animation").pauseAnimation();
}
for(var i = 0, len = gdjs.GameScene1Code.GDpeach_95952Objects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpeach_95952Objects2[i].getBehavior("Animation").pauseAnimation();
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.GameScene1Code.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = runtimeScene.getOnceTriggers().triggerOnce(10079508);
}
}
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burger"), gdjs.GameScene1Code.GDBurgerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ketchup"), gdjs.GameScene1Code.GDKetchupObjects2);
gdjs.copyArray(runtimeScene.getObjects("cookie"), gdjs.GameScene1Code.GDcookieObjects2);
gdjs.copyArray(runtimeScene.getObjects("peach_2"), gdjs.GameScene1Code.GDpeach_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("pizza"), gdjs.GameScene1Code.GDpizzaObjects2);
gdjs.copyArray(runtimeScene.getObjects("table"), gdjs.GameScene1Code.GDtableObjects2);
gdjs.copyArray(runtimeScene.getObjects("wing"), gdjs.GameScene1Code.GDwingObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{for(var i = 0, len = gdjs.GameScene1Code.GDBurgerObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDBurgerObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameScene1Code.GDpizzaObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpizzaObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameScene1Code.GDwingObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDwingObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameScene1Code.GDcookieObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDcookieObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameScene1Code.GDtableObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDtableObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameScene1Code.GDKetchupObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDKetchupObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameScene1Code.GDpeach_95952Objects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpeach_95952Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10056764);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burger"), gdjs.GameScene1Code.GDBurgerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ketchup"), gdjs.GameScene1Code.GDKetchupObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameScene1Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("cookie"), gdjs.GameScene1Code.GDcookieObjects2);
gdjs.copyArray(runtimeScene.getObjects("peach_2"), gdjs.GameScene1Code.GDpeach_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("pizza"), gdjs.GameScene1Code.GDpizzaObjects2);
gdjs.copyArray(runtimeScene.getObjects("table"), gdjs.GameScene1Code.GDtableObjects2);
gdjs.copyArray(runtimeScene.getObjects("wing"), gdjs.GameScene1Code.GDwingObjects2);
{for(var i = 0, len = gdjs.GameScene1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setMaxFallingSpeed(1000, false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(10);
}{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(false);
}{for(var i = 0, len = gdjs.GameScene1Code.GDBurgerObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDBurgerObjects2[i].getBehavior("Animation").resumeAnimation();
}
for(var i = 0, len = gdjs.GameScene1Code.GDpizzaObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpizzaObjects2[i].getBehavior("Animation").resumeAnimation();
}
for(var i = 0, len = gdjs.GameScene1Code.GDwingObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDwingObjects2[i].getBehavior("Animation").resumeAnimation();
}
for(var i = 0, len = gdjs.GameScene1Code.GDcookieObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDcookieObjects2[i].getBehavior("Animation").resumeAnimation();
}
for(var i = 0, len = gdjs.GameScene1Code.GDtableObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDtableObjects2[i].getBehavior("Animation").resumeAnimation();
}
for(var i = 0, len = gdjs.GameScene1Code.GDKetchupObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDKetchupObjects2[i].getBehavior("Animation").resumeAnimation();
}
for(var i = 0, len = gdjs.GameScene1Code.GDpeach_95952Objects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpeach_95952Objects2[i].getBehavior("Animation").resumeAnimation();
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Restart_Button"), gdjs.GameScene1Code.GDRestart_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameScene1Code.GDRestart_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameScene1Code.GDRestart_9595ButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameScene1Code.GDRestart_9595ButtonObjects2[k] = gdjs.GameScene1Code.GDRestart_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.GameScene1Code.GDRestart_9595ButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = runtimeScene.getOnceTriggers().triggerOnce(10042620);
}
}
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burger"), gdjs.GameScene1Code.GDBurgerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ketchup"), gdjs.GameScene1Code.GDKetchupObjects2);
gdjs.copyArray(runtimeScene.getObjects("cookie"), gdjs.GameScene1Code.GDcookieObjects2);
gdjs.copyArray(runtimeScene.getObjects("peach_2"), gdjs.GameScene1Code.GDpeach_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("pizza"), gdjs.GameScene1Code.GDpizzaObjects2);
gdjs.copyArray(runtimeScene.getObjects("table"), gdjs.GameScene1Code.GDtableObjects2);
gdjs.copyArray(runtimeScene.getObjects("wing"), gdjs.GameScene1Code.GDwingObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{for(var i = 0, len = gdjs.GameScene1Code.GDBurgerObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDBurgerObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameScene1Code.GDpizzaObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpizzaObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameScene1Code.GDwingObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDwingObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameScene1Code.GDcookieObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDcookieObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameScene1Code.GDtableObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDtableObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameScene1Code.GDKetchupObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDKetchupObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameScene1Code.GDpeach_95952Objects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpeach_95952Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.GameScene1Code.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "Scoretimer", 0.2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).add(1);
}}

}


};gdjs.GameScene1Code.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ScoreRun"), gdjs.GameScene1Code.GDScoreRunObjects2);
{for(var i = 0, len = gdjs.GameScene1Code.GDScoreRunObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScoreRunObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameScene1Code.eventsList10(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.GameScene1Code.eventsList12 = function(runtimeScene) {

};gdjs.GameScene1Code.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ScrollGround"), gdjs.GameScene1Code.GDScrollGroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("ScrollGround2"), gdjs.GameScene1Code.GDScrollGround2Objects2);

gdjs.GameScene1Code.forEachTotalCount3 = 0;
gdjs.GameScene1Code.forEachObjects3.length = 0;
gdjs.GameScene1Code.forEachCount0_3 = gdjs.GameScene1Code.GDScrollGroundObjects2.length;
gdjs.GameScene1Code.forEachTotalCount3 += gdjs.GameScene1Code.forEachCount0_3;
gdjs.GameScene1Code.forEachObjects3.push.apply(gdjs.GameScene1Code.forEachObjects3,gdjs.GameScene1Code.GDScrollGroundObjects2);
gdjs.GameScene1Code.forEachCount1_3 = gdjs.GameScene1Code.GDScrollGround2Objects2.length;
gdjs.GameScene1Code.forEachTotalCount3 += gdjs.GameScene1Code.forEachCount1_3;
gdjs.GameScene1Code.forEachObjects3.push.apply(gdjs.GameScene1Code.forEachObjects3,gdjs.GameScene1Code.GDScrollGround2Objects2);
for (gdjs.GameScene1Code.forEachIndex3 = 0;gdjs.GameScene1Code.forEachIndex3 < gdjs.GameScene1Code.forEachTotalCount3;++gdjs.GameScene1Code.forEachIndex3) {
gdjs.GameScene1Code.GDScrollGroundObjects3.length = 0;

gdjs.GameScene1Code.GDScrollGround2Objects3.length = 0;


if (gdjs.GameScene1Code.forEachIndex3 < gdjs.GameScene1Code.forEachCount0_3) {
    gdjs.GameScene1Code.GDScrollGroundObjects3.push(gdjs.GameScene1Code.forEachObjects3[gdjs.GameScene1Code.forEachIndex3]);
}
else if (gdjs.GameScene1Code.forEachIndex3 < gdjs.GameScene1Code.forEachCount0_3+gdjs.GameScene1Code.forEachCount1_3) {
    gdjs.GameScene1Code.GDScrollGround2Objects3.push(gdjs.GameScene1Code.forEachObjects3[gdjs.GameScene1Code.forEachIndex3]);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameScene1Code.GDScrollGroundObjects3.length;i<l;++i) {
    if ( gdjs.GameScene1Code.GDScrollGroundObjects3[i].getX() < -((gdjs.GameScene1Code.GDScrollGroundObjects3[i].getWidth())) ) {
        isConditionTrue_0 = true;
        gdjs.GameScene1Code.GDScrollGroundObjects3[k] = gdjs.GameScene1Code.GDScrollGroundObjects3[i];
        ++k;
    }
}
gdjs.GameScene1Code.GDScrollGroundObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.GameScene1Code.GDScrollGround2Objects3.length;i<l;++i) {
    if ( gdjs.GameScene1Code.GDScrollGround2Objects3[i].getX() < -((gdjs.GameScene1Code.GDScrollGround2Objects3[i].getWidth())) ) {
        isConditionTrue_0 = true;
        gdjs.GameScene1Code.GDScrollGround2Objects3[k] = gdjs.GameScene1Code.GDScrollGround2Objects3[i];
        ++k;
    }
}
gdjs.GameScene1Code.GDScrollGround2Objects3.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.GameScene1Code.GDScrollGroundObjects3.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGroundObjects3[i].setX((gdjs.GameScene1Code.GDScrollGroundObjects3[i].getWidth()) + 15);
}
for(var i = 0, len = gdjs.GameScene1Code.GDScrollGround2Objects3.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGround2Objects3[i].setX((gdjs.GameScene1Code.GDScrollGround2Objects3[i].getWidth()) + 15);
}
}}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ScrollGround"), gdjs.GameScene1Code.GDScrollGroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("ScrollGround2"), gdjs.GameScene1Code.GDScrollGround2Objects2);
{for(var i = 0, len = gdjs.GameScene1Code.GDScrollGroundObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGroundObjects2[i].setX(gdjs.GameScene1Code.GDScrollGroundObjects2[i].getX() - (2));
}
for(var i = 0, len = gdjs.GameScene1Code.GDScrollGround2Objects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGround2Objects2[i].setX(gdjs.GameScene1Code.GDScrollGround2Objects2[i].getX() - (2));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GameOver"), gdjs.GameScene1Code.GDGameOverObjects2);
{for(var i = 0, len = gdjs.GameScene1Code.GDGameOverObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDGameOverObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScrollGround"), gdjs.GameScene1Code.GDScrollGroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("ScrollGround2"), gdjs.GameScene1Code.GDScrollGround2Objects2);
{for(var i = 0, len = gdjs.GameScene1Code.GDScrollGroundObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGroundObjects2[i].setX(gdjs.GameScene1Code.GDScrollGroundObjects2[i].getX() + (2));
}
for(var i = 0, len = gdjs.GameScene1Code.GDScrollGround2Objects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGround2Objects2[i].setX(gdjs.GameScene1Code.GDScrollGround2Objects2[i].getX() + (2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Restart_Button"), gdjs.GameScene1Code.GDRestart_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameScene1Code.GDRestart_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameScene1Code.GDRestart_9595ButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameScene1Code.GDRestart_9595ButtonObjects2[k] = gdjs.GameScene1Code.GDRestart_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.GameScene1Code.GDRestart_9595ButtonObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScrollGround"), gdjs.GameScene1Code.GDScrollGroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("ScrollGround2"), gdjs.GameScene1Code.GDScrollGround2Objects2);
{for(var i = 0, len = gdjs.GameScene1Code.GDScrollGroundObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGroundObjects2[i].setX(0);
}
for(var i = 0, len = gdjs.GameScene1Code.GDScrollGround2Objects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGround2Objects2[i].setX(0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScrollGround"), gdjs.GameScene1Code.GDScrollGroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("ScrollGround2"), gdjs.GameScene1Code.GDScrollGround2Objects2);
{for(var i = 0, len = gdjs.GameScene1Code.GDScrollGroundObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGroundObjects2[i].setX(0);
}
for(var i = 0, len = gdjs.GameScene1Code.GDScrollGround2Objects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGround2Objects2[i].setX(0);
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.GameScene1Code.GDPlayerObjects2});
gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.GameScene1Code.GDCoinObjects2});
gdjs.GameScene1Code.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.GameScene1Code.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameScene1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDPlayerObjects2Objects, gdjs.GameScene1Code.mapOfGDgdjs_9546GameScene1Code_9546GDCoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false, false);
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14818252);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameScene1Code.GDCoinObjects2 */
gdjs.copyArray(runtimeScene.getObjects("CoinScore"), gdjs.GameScene1Code.GDCoinScoreObjects2);
gdjs.copyArray(runtimeScene.getObjects("FinalCoinScore"), gdjs.GameScene1Code.GDFinalCoinScoreObjects2);
{for(var i = 0, len = gdjs.GameScene1Code.GDCoinObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDCoinObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameScene1Code.GDCoinScoreObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDCoinScoreObjects2[i].getBehavior("RollingCounter").SetValue(gdjs.GameScene1Code.GDCoinScoreObjects2[i].getBehavior("RollingCounter").Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) + (1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameScene1Code.GDFinalCoinScoreObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDFinalCoinScoreObjects2[i].getBehavior("Text").setText(gdjs.GameScene1Code.GDFinalCoinScoreObjects2[i].getBehavior("Text").getText() + ("1"));
}
}{runtimeScene.getGame().getVariables().getFromIndex(4).add(1);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.GameScene1Code.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) >= 100;
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(7);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) >= 500;
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScrollGround"), gdjs.GameScene1Code.GDScrollGroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("ScrollGround2"), gdjs.GameScene1Code.GDScrollGround2Objects2);
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(13);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(2);
}{for(var i = 0, len = gdjs.GameScene1Code.GDScrollGroundObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGroundObjects2[i].setX(gdjs.GameScene1Code.GDScrollGroundObjects2[i].getX() - (2.5));
}
for(var i = 0, len = gdjs.GameScene1Code.GDScrollGround2Objects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGround2Objects2[i].setX(gdjs.GameScene1Code.GDScrollGround2Objects2[i].getX() - (2.5));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) >= 1000;
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScrollGround"), gdjs.GameScene1Code.GDScrollGroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("ScrollGround2"), gdjs.GameScene1Code.GDScrollGround2Objects2);
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(14);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(3);
}{for(var i = 0, len = gdjs.GameScene1Code.GDScrollGroundObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGroundObjects2[i].setX(gdjs.GameScene1Code.GDScrollGroundObjects2[i].getX() - (3));
}
for(var i = 0, len = gdjs.GameScene1Code.GDScrollGround2Objects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGround2Objects2[i].setX(gdjs.GameScene1Code.GDScrollGround2Objects2[i].getX() - (3));
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.GameScene1Code.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(10), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14828228);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("LivesLeft"), gdjs.GameScene1Code.GDLivesLeftObjects2);
{for(var i = 0, len = gdjs.GameScene1Code.GDLivesLeftObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDLivesLeftObjects2[i].getBehavior("RollingCounter").SetValue(4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14829412);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("LivesLeft"), gdjs.GameScene1Code.GDLivesLeftObjects2);
{for(var i = 0, len = gdjs.GameScene1Code.GDLivesLeftObjects2.length ;i < len;++i) {
    gdjs.GameScene1Code.GDLivesLeftObjects2[i].getBehavior("RollingCounter").SetValue(gdjs.GameScene1Code.GDLivesLeftObjects2[i].getBehavior("RollingCounter").Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LivesLeft"), gdjs.GameScene1Code.GDLivesLeftObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameScene1Code.GDLivesLeftObjects1.length;i<l;++i) {
    if ( gdjs.GameScene1Code.GDLivesLeftObjects1[i].getBehavior("RollingCounter").Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameScene1Code.GDLivesLeftObjects1[k] = gdjs.GameScene1Code.GDLivesLeftObjects1[i];
        ++k;
    }
}
gdjs.GameScene1Code.GDLivesLeftObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14830388);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burger"), gdjs.GameScene1Code.GDBurgerObjects1);
gdjs.copyArray(runtimeScene.getObjects("GameOver"), gdjs.GameScene1Code.GDGameOverObjects1);
gdjs.copyArray(runtimeScene.getObjects("Ketchup"), gdjs.GameScene1Code.GDKetchupObjects1);
gdjs.copyArray(runtimeScene.getObjects("Restart_Button"), gdjs.GameScene1Code.GDRestart_9595ButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("ScrollGround"), gdjs.GameScene1Code.GDScrollGroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("ScrollGround2"), gdjs.GameScene1Code.GDScrollGround2Objects1);
gdjs.copyArray(runtimeScene.getObjects("cookie"), gdjs.GameScene1Code.GDcookieObjects1);
gdjs.copyArray(runtimeScene.getObjects("logo"), gdjs.GameScene1Code.GDlogoObjects1);
gdjs.copyArray(runtimeScene.getObjects("peach_2"), gdjs.GameScene1Code.GDpeach_95952Objects1);
gdjs.copyArray(runtimeScene.getObjects("pizza"), gdjs.GameScene1Code.GDpizzaObjects1);
gdjs.copyArray(runtimeScene.getObjects("table"), gdjs.GameScene1Code.GDtableObjects1);
gdjs.copyArray(runtimeScene.getObjects("wing"), gdjs.GameScene1Code.GDwingObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(true);
}{for(var i = 0, len = gdjs.GameScene1Code.GDGameOverObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDGameOverObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameScene1Code.GDScrollGroundObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGroundObjects1[i].hide();
}
for(var i = 0, len = gdjs.GameScene1Code.GDScrollGround2Objects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDScrollGround2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameScene1Code.GDRestart_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDRestart_9595ButtonObjects1[i].Activate(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameScene1Code.GDBurgerObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDBurgerObjects1[i].hide();
}
for(var i = 0, len = gdjs.GameScene1Code.GDpizzaObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpizzaObjects1[i].hide();
}
for(var i = 0, len = gdjs.GameScene1Code.GDwingObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDwingObjects1[i].hide();
}
for(var i = 0, len = gdjs.GameScene1Code.GDcookieObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDcookieObjects1[i].hide();
}
for(var i = 0, len = gdjs.GameScene1Code.GDtableObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDtableObjects1[i].hide();
}
for(var i = 0, len = gdjs.GameScene1Code.GDKetchupObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDKetchupObjects1[i].hide();
}
for(var i = 0, len = gdjs.GameScene1Code.GDpeach_95952Objects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDpeach_95952Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameScene1Code.GDlogoObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDlogoObjects1[i].hide();
}
}{runtimeScene.getScene().getVariables().getFromIndex(11).setBoolean(true);
}{gdjs.evtTools.firebaseTools.firestore.writeField("UserInfo", runtimeScene.getGame().getVariables().getFromIndex(7).getAsString(), "runScore", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2))), gdjs.VariablesContainer.badVariable, true);
}{gdjs.evtTools.firebaseTools.firestore.writeField("UserInfo", runtimeScene.getGame().getVariables().getFromIndex(7).getAsString(), "Coins", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))), gdjs.VariablesContainer.badVariable, true);
}}

}


};gdjs.GameScene1Code.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.GameScene1Code.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.GameScene1Code.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10052964);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(7).setString(gdjs.evtsExt__UUID__GenerateUUIDv4.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}}

}


{


gdjs.GameScene1Code.eventsList0(runtimeScene);
}


{


gdjs.GameScene1Code.eventsList1(runtimeScene);
}


{


gdjs.GameScene1Code.eventsList3(runtimeScene);
}


{


gdjs.GameScene1Code.eventsList5(runtimeScene);
}


{


gdjs.GameScene1Code.eventsList6(runtimeScene);
}


{


gdjs.GameScene1Code.eventsList7(runtimeScene);
}


{


gdjs.GameScene1Code.eventsList8(runtimeScene);
}


{


gdjs.GameScene1Code.eventsList9(runtimeScene);
}


{


gdjs.GameScene1Code.eventsList11(runtimeScene);
}


{


gdjs.GameScene1Code.eventsList13(runtimeScene);
}


{


gdjs.GameScene1Code.eventsList14(runtimeScene);
}


{


gdjs.GameScene1Code.eventsList15(runtimeScene);
}


{


gdjs.GameScene1Code.eventsList17(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("LivesLeft"), gdjs.GameScene1Code.GDLivesLeftObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameScene1Code.GDLivesLeftObjects1.length;i<l;++i) {
    if ( gdjs.GameScene1Code.GDLivesLeftObjects1[i].getBehavior("RollingCounter").Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameScene1Code.GDLivesLeftObjects1[k] = gdjs.GameScene1Code.GDLivesLeftObjects1[i];
        ++k;
    }
}
gdjs.GameScene1Code.GDLivesLeftObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GameOver"), gdjs.GameScene1Code.GDGameOverObjects1);
gdjs.copyArray(runtimeScene.getObjects("Restart_Button"), gdjs.GameScene1Code.GDRestart_9595ButtonObjects1);
{for(var i = 0, len = gdjs.GameScene1Code.GDRestart_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDRestart_9595ButtonObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameScene1Code.GDGameOverObjects1.length ;i < len;++i) {
    gdjs.GameScene1Code.GDGameOverObjects1[i].hide(false);
}
}}

}


};

gdjs.GameScene1Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameScene1Code.GDPlayerObjects1.length = 0;
gdjs.GameScene1Code.GDPlayerObjects2.length = 0;
gdjs.GameScene1Code.GDPlayerObjects3.length = 0;
gdjs.GameScene1Code.GDPlayerObjects4.length = 0;
gdjs.GameScene1Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.GameScene1Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.GameScene1Code.GDNewTiledSpriteObjects3.length = 0;
gdjs.GameScene1Code.GDNewTiledSpriteObjects4.length = 0;
gdjs.GameScene1Code.GDPeachObjects1.length = 0;
gdjs.GameScene1Code.GDPeachObjects2.length = 0;
gdjs.GameScene1Code.GDPeachObjects3.length = 0;
gdjs.GameScene1Code.GDPeachObjects4.length = 0;
gdjs.GameScene1Code.GDBurgerObjects1.length = 0;
gdjs.GameScene1Code.GDBurgerObjects2.length = 0;
gdjs.GameScene1Code.GDBurgerObjects3.length = 0;
gdjs.GameScene1Code.GDBurgerObjects4.length = 0;
gdjs.GameScene1Code.GDpizzaObjects1.length = 0;
gdjs.GameScene1Code.GDpizzaObjects2.length = 0;
gdjs.GameScene1Code.GDpizzaObjects3.length = 0;
gdjs.GameScene1Code.GDpizzaObjects4.length = 0;
gdjs.GameScene1Code.GDtableObjects1.length = 0;
gdjs.GameScene1Code.GDtableObjects2.length = 0;
gdjs.GameScene1Code.GDtableObjects3.length = 0;
gdjs.GameScene1Code.GDtableObjects4.length = 0;
gdjs.GameScene1Code.GDwingObjects1.length = 0;
gdjs.GameScene1Code.GDwingObjects2.length = 0;
gdjs.GameScene1Code.GDwingObjects3.length = 0;
gdjs.GameScene1Code.GDwingObjects4.length = 0;
gdjs.GameScene1Code.GDcookieObjects1.length = 0;
gdjs.GameScene1Code.GDcookieObjects2.length = 0;
gdjs.GameScene1Code.GDcookieObjects3.length = 0;
gdjs.GameScene1Code.GDcookieObjects4.length = 0;
gdjs.GameScene1Code.GDKetchupObjects1.length = 0;
gdjs.GameScene1Code.GDKetchupObjects2.length = 0;
gdjs.GameScene1Code.GDKetchupObjects3.length = 0;
gdjs.GameScene1Code.GDKetchupObjects4.length = 0;
gdjs.GameScene1Code.GDSpawnPointObjects1.length = 0;
gdjs.GameScene1Code.GDSpawnPointObjects2.length = 0;
gdjs.GameScene1Code.GDSpawnPointObjects3.length = 0;
gdjs.GameScene1Code.GDSpawnPointObjects4.length = 0;
gdjs.GameScene1Code.GDpeach_95952Objects1.length = 0;
gdjs.GameScene1Code.GDpeach_95952Objects2.length = 0;
gdjs.GameScene1Code.GDpeach_95952Objects3.length = 0;
gdjs.GameScene1Code.GDpeach_95952Objects4.length = 0;
gdjs.GameScene1Code.GDScrollGroundObjects1.length = 0;
gdjs.GameScene1Code.GDScrollGroundObjects2.length = 0;
gdjs.GameScene1Code.GDScrollGroundObjects3.length = 0;
gdjs.GameScene1Code.GDScrollGroundObjects4.length = 0;
gdjs.GameScene1Code.GDScrollGround2Objects1.length = 0;
gdjs.GameScene1Code.GDScrollGround2Objects2.length = 0;
gdjs.GameScene1Code.GDScrollGround2Objects3.length = 0;
gdjs.GameScene1Code.GDScrollGround2Objects4.length = 0;
gdjs.GameScene1Code.GDCoinObjects1.length = 0;
gdjs.GameScene1Code.GDCoinObjects2.length = 0;
gdjs.GameScene1Code.GDCoinObjects3.length = 0;
gdjs.GameScene1Code.GDCoinObjects4.length = 0;
gdjs.GameScene1Code.GDlogoObjects1.length = 0;
gdjs.GameScene1Code.GDlogoObjects2.length = 0;
gdjs.GameScene1Code.GDlogoObjects3.length = 0;
gdjs.GameScene1Code.GDlogoObjects4.length = 0;
gdjs.GameScene1Code.GDScoreTitleObjects1.length = 0;
gdjs.GameScene1Code.GDScoreTitleObjects2.length = 0;
gdjs.GameScene1Code.GDScoreTitleObjects3.length = 0;
gdjs.GameScene1Code.GDScoreTitleObjects4.length = 0;
gdjs.GameScene1Code.GDLivesLeftObjects1.length = 0;
gdjs.GameScene1Code.GDLivesLeftObjects2.length = 0;
gdjs.GameScene1Code.GDLivesLeftObjects3.length = 0;
gdjs.GameScene1Code.GDLivesLeftObjects4.length = 0;
gdjs.GameScene1Code.GDButton_9595AObjects1.length = 0;
gdjs.GameScene1Code.GDButton_9595AObjects2.length = 0;
gdjs.GameScene1Code.GDButton_9595AObjects3.length = 0;
gdjs.GameScene1Code.GDButton_9595AObjects4.length = 0;
gdjs.GameScene1Code.GDB_9595buttonObjects1.length = 0;
gdjs.GameScene1Code.GDB_9595buttonObjects2.length = 0;
gdjs.GameScene1Code.GDB_9595buttonObjects3.length = 0;
gdjs.GameScene1Code.GDB_9595buttonObjects4.length = 0;
gdjs.GameScene1Code.GDCoinScoreObjects1.length = 0;
gdjs.GameScene1Code.GDCoinScoreObjects2.length = 0;
gdjs.GameScene1Code.GDCoinScoreObjects3.length = 0;
gdjs.GameScene1Code.GDCoinScoreObjects4.length = 0;
gdjs.GameScene1Code.GDScoreRunObjects1.length = 0;
gdjs.GameScene1Code.GDScoreRunObjects2.length = 0;
gdjs.GameScene1Code.GDScoreRunObjects3.length = 0;
gdjs.GameScene1Code.GDScoreRunObjects4.length = 0;
gdjs.GameScene1Code.GDgameboy_9595joystickObjects1.length = 0;
gdjs.GameScene1Code.GDgameboy_9595joystickObjects2.length = 0;
gdjs.GameScene1Code.GDgameboy_9595joystickObjects3.length = 0;
gdjs.GameScene1Code.GDgameboy_9595joystickObjects4.length = 0;
gdjs.GameScene1Code.GDSave_9595ButtonObjects1.length = 0;
gdjs.GameScene1Code.GDSave_9595ButtonObjects2.length = 0;
gdjs.GameScene1Code.GDSave_9595ButtonObjects3.length = 0;
gdjs.GameScene1Code.GDSave_9595ButtonObjects4.length = 0;
gdjs.GameScene1Code.GDRestart_9595ButtonObjects1.length = 0;
gdjs.GameScene1Code.GDRestart_9595ButtonObjects2.length = 0;
gdjs.GameScene1Code.GDRestart_9595ButtonObjects3.length = 0;
gdjs.GameScene1Code.GDRestart_9595ButtonObjects4.length = 0;
gdjs.GameScene1Code.GDGameOverObjects1.length = 0;
gdjs.GameScene1Code.GDGameOverObjects2.length = 0;
gdjs.GameScene1Code.GDGameOverObjects3.length = 0;
gdjs.GameScene1Code.GDGameOverObjects4.length = 0;
gdjs.GameScene1Code.GDScrollGroundStillObjects1.length = 0;
gdjs.GameScene1Code.GDScrollGroundStillObjects2.length = 0;
gdjs.GameScene1Code.GDScrollGroundStillObjects3.length = 0;
gdjs.GameScene1Code.GDScrollGroundStillObjects4.length = 0;
gdjs.GameScene1Code.GDFinalCoinScoreObjects1.length = 0;
gdjs.GameScene1Code.GDFinalCoinScoreObjects2.length = 0;
gdjs.GameScene1Code.GDFinalCoinScoreObjects3.length = 0;
gdjs.GameScene1Code.GDFinalCoinScoreObjects4.length = 0;
gdjs.GameScene1Code.GDRegister_9595ButtonObjects1.length = 0;
gdjs.GameScene1Code.GDRegister_9595ButtonObjects2.length = 0;
gdjs.GameScene1Code.GDRegister_9595ButtonObjects3.length = 0;
gdjs.GameScene1Code.GDRegister_9595ButtonObjects4.length = 0;

gdjs.GameScene1Code.eventsList18(runtimeScene);
gdjs.GameScene1Code.GDPlayerObjects1.length = 0;
gdjs.GameScene1Code.GDPlayerObjects2.length = 0;
gdjs.GameScene1Code.GDPlayerObjects3.length = 0;
gdjs.GameScene1Code.GDPlayerObjects4.length = 0;
gdjs.GameScene1Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.GameScene1Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.GameScene1Code.GDNewTiledSpriteObjects3.length = 0;
gdjs.GameScene1Code.GDNewTiledSpriteObjects4.length = 0;
gdjs.GameScene1Code.GDPeachObjects1.length = 0;
gdjs.GameScene1Code.GDPeachObjects2.length = 0;
gdjs.GameScene1Code.GDPeachObjects3.length = 0;
gdjs.GameScene1Code.GDPeachObjects4.length = 0;
gdjs.GameScene1Code.GDBurgerObjects1.length = 0;
gdjs.GameScene1Code.GDBurgerObjects2.length = 0;
gdjs.GameScene1Code.GDBurgerObjects3.length = 0;
gdjs.GameScene1Code.GDBurgerObjects4.length = 0;
gdjs.GameScene1Code.GDpizzaObjects1.length = 0;
gdjs.GameScene1Code.GDpizzaObjects2.length = 0;
gdjs.GameScene1Code.GDpizzaObjects3.length = 0;
gdjs.GameScene1Code.GDpizzaObjects4.length = 0;
gdjs.GameScene1Code.GDtableObjects1.length = 0;
gdjs.GameScene1Code.GDtableObjects2.length = 0;
gdjs.GameScene1Code.GDtableObjects3.length = 0;
gdjs.GameScene1Code.GDtableObjects4.length = 0;
gdjs.GameScene1Code.GDwingObjects1.length = 0;
gdjs.GameScene1Code.GDwingObjects2.length = 0;
gdjs.GameScene1Code.GDwingObjects3.length = 0;
gdjs.GameScene1Code.GDwingObjects4.length = 0;
gdjs.GameScene1Code.GDcookieObjects1.length = 0;
gdjs.GameScene1Code.GDcookieObjects2.length = 0;
gdjs.GameScene1Code.GDcookieObjects3.length = 0;
gdjs.GameScene1Code.GDcookieObjects4.length = 0;
gdjs.GameScene1Code.GDKetchupObjects1.length = 0;
gdjs.GameScene1Code.GDKetchupObjects2.length = 0;
gdjs.GameScene1Code.GDKetchupObjects3.length = 0;
gdjs.GameScene1Code.GDKetchupObjects4.length = 0;
gdjs.GameScene1Code.GDSpawnPointObjects1.length = 0;
gdjs.GameScene1Code.GDSpawnPointObjects2.length = 0;
gdjs.GameScene1Code.GDSpawnPointObjects3.length = 0;
gdjs.GameScene1Code.GDSpawnPointObjects4.length = 0;
gdjs.GameScene1Code.GDpeach_95952Objects1.length = 0;
gdjs.GameScene1Code.GDpeach_95952Objects2.length = 0;
gdjs.GameScene1Code.GDpeach_95952Objects3.length = 0;
gdjs.GameScene1Code.GDpeach_95952Objects4.length = 0;
gdjs.GameScene1Code.GDScrollGroundObjects1.length = 0;
gdjs.GameScene1Code.GDScrollGroundObjects2.length = 0;
gdjs.GameScene1Code.GDScrollGroundObjects3.length = 0;
gdjs.GameScene1Code.GDScrollGroundObjects4.length = 0;
gdjs.GameScene1Code.GDScrollGround2Objects1.length = 0;
gdjs.GameScene1Code.GDScrollGround2Objects2.length = 0;
gdjs.GameScene1Code.GDScrollGround2Objects3.length = 0;
gdjs.GameScene1Code.GDScrollGround2Objects4.length = 0;
gdjs.GameScene1Code.GDCoinObjects1.length = 0;
gdjs.GameScene1Code.GDCoinObjects2.length = 0;
gdjs.GameScene1Code.GDCoinObjects3.length = 0;
gdjs.GameScene1Code.GDCoinObjects4.length = 0;
gdjs.GameScene1Code.GDlogoObjects1.length = 0;
gdjs.GameScene1Code.GDlogoObjects2.length = 0;
gdjs.GameScene1Code.GDlogoObjects3.length = 0;
gdjs.GameScene1Code.GDlogoObjects4.length = 0;
gdjs.GameScene1Code.GDScoreTitleObjects1.length = 0;
gdjs.GameScene1Code.GDScoreTitleObjects2.length = 0;
gdjs.GameScene1Code.GDScoreTitleObjects3.length = 0;
gdjs.GameScene1Code.GDScoreTitleObjects4.length = 0;
gdjs.GameScene1Code.GDLivesLeftObjects1.length = 0;
gdjs.GameScene1Code.GDLivesLeftObjects2.length = 0;
gdjs.GameScene1Code.GDLivesLeftObjects3.length = 0;
gdjs.GameScene1Code.GDLivesLeftObjects4.length = 0;
gdjs.GameScene1Code.GDButton_9595AObjects1.length = 0;
gdjs.GameScene1Code.GDButton_9595AObjects2.length = 0;
gdjs.GameScene1Code.GDButton_9595AObjects3.length = 0;
gdjs.GameScene1Code.GDButton_9595AObjects4.length = 0;
gdjs.GameScene1Code.GDB_9595buttonObjects1.length = 0;
gdjs.GameScene1Code.GDB_9595buttonObjects2.length = 0;
gdjs.GameScene1Code.GDB_9595buttonObjects3.length = 0;
gdjs.GameScene1Code.GDB_9595buttonObjects4.length = 0;
gdjs.GameScene1Code.GDCoinScoreObjects1.length = 0;
gdjs.GameScene1Code.GDCoinScoreObjects2.length = 0;
gdjs.GameScene1Code.GDCoinScoreObjects3.length = 0;
gdjs.GameScene1Code.GDCoinScoreObjects4.length = 0;
gdjs.GameScene1Code.GDScoreRunObjects1.length = 0;
gdjs.GameScene1Code.GDScoreRunObjects2.length = 0;
gdjs.GameScene1Code.GDScoreRunObjects3.length = 0;
gdjs.GameScene1Code.GDScoreRunObjects4.length = 0;
gdjs.GameScene1Code.GDgameboy_9595joystickObjects1.length = 0;
gdjs.GameScene1Code.GDgameboy_9595joystickObjects2.length = 0;
gdjs.GameScene1Code.GDgameboy_9595joystickObjects3.length = 0;
gdjs.GameScene1Code.GDgameboy_9595joystickObjects4.length = 0;
gdjs.GameScene1Code.GDSave_9595ButtonObjects1.length = 0;
gdjs.GameScene1Code.GDSave_9595ButtonObjects2.length = 0;
gdjs.GameScene1Code.GDSave_9595ButtonObjects3.length = 0;
gdjs.GameScene1Code.GDSave_9595ButtonObjects4.length = 0;
gdjs.GameScene1Code.GDRestart_9595ButtonObjects1.length = 0;
gdjs.GameScene1Code.GDRestart_9595ButtonObjects2.length = 0;
gdjs.GameScene1Code.GDRestart_9595ButtonObjects3.length = 0;
gdjs.GameScene1Code.GDRestart_9595ButtonObjects4.length = 0;
gdjs.GameScene1Code.GDGameOverObjects1.length = 0;
gdjs.GameScene1Code.GDGameOverObjects2.length = 0;
gdjs.GameScene1Code.GDGameOverObjects3.length = 0;
gdjs.GameScene1Code.GDGameOverObjects4.length = 0;
gdjs.GameScene1Code.GDScrollGroundStillObjects1.length = 0;
gdjs.GameScene1Code.GDScrollGroundStillObjects2.length = 0;
gdjs.GameScene1Code.GDScrollGroundStillObjects3.length = 0;
gdjs.GameScene1Code.GDScrollGroundStillObjects4.length = 0;
gdjs.GameScene1Code.GDFinalCoinScoreObjects1.length = 0;
gdjs.GameScene1Code.GDFinalCoinScoreObjects2.length = 0;
gdjs.GameScene1Code.GDFinalCoinScoreObjects3.length = 0;
gdjs.GameScene1Code.GDFinalCoinScoreObjects4.length = 0;
gdjs.GameScene1Code.GDRegister_9595ButtonObjects1.length = 0;
gdjs.GameScene1Code.GDRegister_9595ButtonObjects2.length = 0;
gdjs.GameScene1Code.GDRegister_9595ButtonObjects3.length = 0;
gdjs.GameScene1Code.GDRegister_9595ButtonObjects4.length = 0;


return;

}

gdjs['GameScene1Code'] = gdjs.GameScene1Code;
